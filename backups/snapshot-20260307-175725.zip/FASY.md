# FASY

**FASY (Formative Assessment System)** � um sistema de gest�o pedag�gica e escolar voltado para apoiar escolas na organiza��o acad�mica e no acompanhamento da aprendizagem.

## Prop�sito

O FASY foi concebido para fortalecer a pr�tica pedag�gica com base em dados e processos claros.

Seu foco principal � a **gest�o pedag�gica com suporte � avalia��o formativa dos alunos**, quando essa abordagem for definida como diretriz pela dire��o pedag�gica do col�gio.

## Vis�o do Sistema

O sistema integra processos essenciais de gest�o escolar e pedag�gica, incluindo:

- gest�o de usu�rios e permiss�es por perfil
- gest�o de alunos, respons�veis e professores
- matr�culas, turmas, disciplinas e ano letivo
- planejamento de aulas, atividades e provas
- composi��o de notas e acompanhamento avaliativo
- calend�rio escolar e mural de avisos
- opera��o multiescola

## Princ�pio Pedag�gico

A avalia��o no FASY pode contemplar tanto pr�ticas tradicionais quanto pr�ticas de **avalia��o formativa**, permitindo que a escola:

- acompanhe o progresso cont�nuo dos estudantes
- registre evid�ncias de aprendizagem ao longo do processo
- utilize devolutivas pedag�gicas para melhoria cont�nua

A ado��o desse modelo � configur�vel e depende da orienta��o institucional da dire��o pedag�gica.

## Nome e Significado

**FASY** = **Formative Assessment System**.
